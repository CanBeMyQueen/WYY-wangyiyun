$(function () {
    var Zjt = $('#Zjt');
    var Yjt = $('#Yjt');
    var $dots = $('#navH').find('a');
    var colors = ['#ededed', '#050408','#FDE8DC', '#D6D2C8','#FEEE35', '#CFC9BE', '#FD9082', '#FCD689']
    var $img3 = $('#img3');
    var $imgs= $('.img').find('.music');
    var num = 0;
    var timer = null;
    $img3.css('background', colors[num]);
    $imgs.each(function (i , e) {
        if(i > 0){
            $(this).fadeOut();
        }
        $dots.eq(i).css('left', i * 20);
    });
    $imgs.on('mouseover', function () {
        clearInterval(timer);
    });
    $imgs.on('mouseout', function () {
        timer = setInterval(function () {
            num++;
            changePage();
        }, 4000);
    });
    Zjt.click(function () {
        num--;
        clearInterval(timer);
        changePage();
        timer = setInterval(function () {
            num++;
            changePage();
        }, 4000);
    });
    Yjt.click(function () {
        num++;
        clearInterval(timer);
        changePage();
        timer = setInterval(function () {
            num++;
            changePage();
        }, 4000);
    });
    $dots.on('click', function () {
        num = $dots.index($(this));
        changePage();
    });

    function changePage() {

        if (num == $imgs.length){
            num=0;
        }
        if (num == -1){
            num=$imgs.length-1;
        }
        $imgs.eq(num).siblings().fadeOut(500);//淡出
        $dots.eq(num).siblings().removeClass('active');//红点消失
        $imgs.eq(num).delay(500).fadeIn(300);//延迟后淡入
        setTimeout(function () {
            $dots.eq(num).addClass('active');
            $img3.css('background', colors[num]);//背景色变化
        }, 500);

    }
    timer = setInterval(function () {
        num++;
        changePage();
    }, 4000);


    var $login = $('.login');
    var $denglu = $login.find('.denglu');
    var $loginList = $login.find('.m-tlist');


    $login.on('mouseover', function () {
        $denglu.css('background', "url(denglusanjiao2.gif) no-repeat right 26px");
        $loginList.fadeIn(0);
    });
    $login.on('mouseout', function () {
        $denglu.css('background', "url(denglusanjiao.gif) no-repeat right 26px");
        $loginList.fadeOut(0);
    });
    $loginList.on('mouseover', function () {
        $denglu.css('background', "url(denglusanjiao2.gif) no-repeat right 26px");
        $loginList.fadeIn(0);
    });
    $loginList.on('mouseout', function () {
        $denglu.css('background', "url(denglusanjiao.gif) no-repeat right 26px");
        $loginList.fadeOut(0);
    });


})

